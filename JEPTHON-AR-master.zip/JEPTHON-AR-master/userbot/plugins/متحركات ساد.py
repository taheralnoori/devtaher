#edit  ~ @RR9R7 for Jmthon 

from telethon import events
from userbot.utils import admin_cmd
from userbot import jmthon
from . import *

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

plugin_category = "extra"
@jmthon.ar_cmd(
    pattern="س1$",
    command=("س1", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    RR9R7 = await reply_id(event)
    if sad:
        jmthon = f"**˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        jmthon += f"✛━━━━━━━━━━━━━✛\n"
        jmthon += f"**الـمتحـرڪـة الأولـى **"
        await event.client.send_file(event.chat_id, sad, caption=jmthon, reply_to=RR9R7)

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jmthon.ar_cmd(
    pattern="س2$",
    command=("س2", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    leo = await reply_id(event)
    if sad2:
        RAZAN = f"**˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـانيـة **"
        await event.client.send_file(event.chat_id, sad2, caption=RAZAN, reply_to=leo)

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jmthon.ar_cmd(
    pattern="س3$",
    command=("س3", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    sic_id = await reply_id(event)
    if sad3:
        RAZAN = f"**˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـالثـة**\n"
        await event.client.send_file(event.chat_id, sad3, caption=RAZAN, reply_to=sic_id)

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jmthon.ar_cmd(
    pattern="س4$",
    command=("س4", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad4:
        RAZAN = f"** ˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـرابـعـة**\n"
        await event.client.send_file(
            event.chat_id, sad4, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jmthon.ar_cmd(
    pattern="س5$",
    command=("س5", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad5:
        RAZAN = f"** ˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـخامسـة**\n"
        await event.client.send_file(
            event.chat_id, sad5, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jmthon.ar_cmd(
    pattern="س6$",
    command=("س6", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad6:
        RAZAN = f"** ˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسادسـة**\n"
        await event.client.send_file(
            event.chat_id, sad6, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jmthon.ar_cmd(
    pattern="س7$",
    command=("س7", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad7:
        RAZAN = f"** ˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسـابعـة**\n"
        await event.client.send_file(
            event.chat_id, sad7, caption=RAZAN, reply_to=reply_to_id
        )
      
      
@jmthon.ar_cmd(
    pattern="س8$",
    command=("س8", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad8:
        RAZAN = f"** ˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الثـامنـة**\n"
        await event.client.send_file(
            event.chat_id, sad8, caption=RAZAN, reply_to=reply_to_id
        )

@jmthon.ar_cmd(
    pattern="س9$",
    command=("س9", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad9:
        RAZAN = f"** ˛ JEP ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة التـاسعـة**\n"
        await event.client.send_file(
            event.chat_id, sad9, caption=RAZAN, reply_to=reply_to_id
        )
#edit  ~ @RR9R7 for Jmthon 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك
